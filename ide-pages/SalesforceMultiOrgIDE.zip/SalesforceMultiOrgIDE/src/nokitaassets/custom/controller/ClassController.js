angular.module('SalesforceSimplifiedApp', []).controller('ClassController', function($scope) {
    //alert("Hello world");
    $scope.cnt = 1200;
});