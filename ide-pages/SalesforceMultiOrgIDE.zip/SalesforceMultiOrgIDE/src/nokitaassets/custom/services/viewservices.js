angular.module('SalesforceSimplifiedApp', []).service('viewservice', function($scope) {
	
	this.classcount = '<p>Hello world</p>';
	
	this.classcount1 = '<div class="website-traffic-ctn">'+
    '<h2><span class="counter">1,000</span></h2>'+
    '<p>Classes</p>'+
'</div>';
});