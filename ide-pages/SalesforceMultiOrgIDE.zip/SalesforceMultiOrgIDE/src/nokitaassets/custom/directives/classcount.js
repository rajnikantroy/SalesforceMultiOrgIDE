angular.module('SalesforceSimplifiedApp', []).directive("classcount", ['viewservice', function(viewservice) {
    return {
        restrict : "E",
        template : viewservice.classcount
    };
}]);