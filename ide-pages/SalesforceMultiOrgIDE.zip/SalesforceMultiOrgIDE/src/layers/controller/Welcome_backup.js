var services = require('../model/MetaDataContainer.js');
var express = require('express');
var jsforce = require('jsforce');
var app = express();
var path = require('path');
var sf = require('node-salesforce');
var environments = [];
var pathObj = path.parse(__filename);
app.use(express.static('nokitaassets'))


app.get('/test', function(req, res) {
	var f = path.join(__dirname, '../../'+'/View/index.html');
});

app.get('/index', function(req, res) {
	getQueryParamsFromMainPage(req, res);
    res.sendFile(path.join(__dirname, '../../','/View/index.html'));
});

app.get('/list', function(req, res) {
	console.log('from list-compare');
	
	if(req.query.instance_url && req.query.access_token){
		console.log('req.query.instance_url : '+ req.query.instance_url);
		console.log('req.query.access_token : '+req.query.access_token);
		console.log('req.query.token_type : '+req.query.token_type);
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		
		//environments.push(environment);
		//QueryAccount(req, res);
		/*storeEnvironmentDetails();
		navigateToWelcomePage();
		var metadata = getParamsFromWelcomePage(req, res);
		*/
	}
    res.sendFile(path.join(__dirname, '../../', '/View/welcome/index.html'));  
});

app.get('/', function(req, res) {
	
	getQueryParamsFromMainPage(req, res);
    res.sendFile(path.join(__dirname, '../../', '/View/index.html'));
});

function getQueryParamsFromMainPage(req, res){
	if(req.query.instance_url && req.query.access_token){
		console.log('req.query.instance_url : '+ req.query.instance_url);
		console.log('req.query.access_token : '+req.query.access_token);
		console.log('req.query.token_type : '+req.query.token_type);
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		environments.push(environment);
		QueryAccount(req, res);
		/*storeEnvironmentDetails();
		navigateToWelcomePage();
		var metadata = getParamsFromWelcomePage(req, res);
		*/
	}
}
function QueryAccount(req, res){
	var latestEnvironment = environments.length;
	var conn = new sf.Connection({
	  instanceUrl : environments[latestEnvironment-1].url,
	  accessToken : environments[latestEnvironment-1].token
	});
	
	console.log('environments.length : '+environments.length);
	var records = [];
	//console.log('conn: '+JSON.stringify(conn));
	console.log("conn status: "+conn.status);
	//res.sendFile(path.join(__dirname, '../../', '/View/list-compare.html'));
	res.sendFile(path.join(__dirname, '../../', '/View/welcome/index.html'));
	conn.query("SELECT Id, Name FROM ApexClass limit 10", function(err, result) {
		
	  if (err) { return console.error(err); }
	  console.log("total : " + result.totalSize);
	  console.log("fetched : " + result.records.length);
	  for(var i=0; i<result.records.length; i++){
			console.log(result.records[i].Name);
	  }
	});
}

app.listen(process.env.port || process.env.PORT || 8080);