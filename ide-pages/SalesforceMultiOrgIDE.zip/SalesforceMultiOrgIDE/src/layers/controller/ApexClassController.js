var metadata = require('../model/MetaDataContainer.js');
var connection = require('../services/Connection.js');
var SOQLServices = require('../services/SOQLServices.js');
var express = require('express');
var app = express();
var path = require('path');
var sf = require('node-salesforce');
var environments = [];
var pathObj = path.parse(__filename);
//app.use(express.static('nokitaassets'))

app.get('/classCount', function(req, res) {
	console.log('from list');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection()){
		res.setHeader('Content-Type', 'application/json');
		var query = metadata.getMetadata('Classes').queryForAll;
	    var data = SOQLServices.getCount(query, connection.getConnection());
	    res.send(JSON.stringify(data));
	}else{
		console.log('token not found! redirecting to login page');
		res.send(JSON.stringify({"Response":"Need access token..."}));
	} 
});

app.get('/classes', function(req, res) {
	console.log('from list');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection()){
		res.setHeader('Content-Type', 'application/json');
		var query = metadata.getMetadata('Classes').queryForAll;
	    var data = SOQLServices.executeQuery(query, connection.getConnection());
	    //console.log("data size: "+data);
	    res.send(JSON.stringify({"Response":data}));
	}else{
		console.log('token not found! redirecting to login page');
		res.send(JSON.stringify({"Response":"Need access token..."}));
	} 
});
//app.listen(process.env.port || process.env.PORT || 8080);