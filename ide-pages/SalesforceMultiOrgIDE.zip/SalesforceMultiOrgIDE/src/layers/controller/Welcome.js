var metadata = require('../model/MetaDataContainer.js');
var connection = require('../services/Connection.js');
var SOQLServices = require('../services/SOQLServices.js');
//var controller = require('../controller/ApexClassController.js');
var controller = require('../controller/OrganizationController.js');

var express = require('express');
var app = express();
var path = require('path');
var sf = require('node-salesforce');
var environments = [];
var pathObj = path.parse(__filename);
app.use(express.static('nokitaassets'))
app.use(express.static('js'))

app.get('/test', function(req, res) {
	var f = path.join(__dirname, '../../'+'/View/index.html');
});

app.get('/testquery', function(req, res) {
	console.log('inside testquery');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
		console.log('connection added');
	}
	console.log('sending for result');
	var query = metadata.getMetadata('Classes').queryForAll;
	console.log('query: '+query);
	var data = SOQLServices.executeQuery(query, connection.getConnection(req, res));
	console.log('data: '+data);
});

app.get('/index', function(req, res) {
	getQueryParamsFromMainPage(req, res);
    res.sendFile(path.join(__dirname, '../../','/View/index.html'));
});

app.get('/list', function(req, res) {
	console.log('from list 1');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection(req, res)){
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/index.html'));
	}else{
		console.log('token not found! redirecting to login page...');
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/login-register.html'));
	} 
});

app.get('/clslist', function(req, res) {
	console.log('from list 1');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection(req, res)){
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/data-table.html'));
	}else{
		console.log('token not found! redirecting to login page...');
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/login-register.html'));
	} 
});

app.get('/org', function(req, res) {
	console.log('from list 1');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection(req, res)){
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/org.html'));
	}else{
		console.log('token not found! redirecting to login page...');
		res.sendFile(path.join(__dirname, '../../', '/View/welcome/login-register.html'));
	} 
});

app.get('/test1234', function(req, res) {
	console.log('thanks for calling test1234...');
	res.send(JSON.stringify({"Response":"Need access token..."}));
});

app.get('/', function(req, res) {
    res.sendFile(path.join(__dirname, '../../', '/View/index.html'));
});


//Clases START
app.get('/classcount', function(req, res) {
	console.log('from classcount');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection(req, res)){
		res.setHeader('Content-Type', 'application/json');
		var query = metadata.getMetadata('Classes').queryForAll;
	    var data = SOQLServices.getCount(query, connection.getConnection(req, res));
	    res.send(JSON.stringify(data));
	}else{
		console.log('token not found! redirecting to login page');
		res.send(JSON.stringify({"Response":"Need access token..."}));
	} 
	res.end();
});

app.get('/classes', function(req, res) {
	console.log('from classes');
	if(req.query.instance_url && req.query.access_token){
		var environment = {};
		environment.url = req.query.instance_url;
		environment.token = req.query.access_token;
		environment.token_type = req.query.token_type;
		environment.scope = req.query.scope;
		connection.addEnvironment(environment);
	}
	if(connection.getConnection(req, res)){
		console.log('got connection');
		res.setHeader('Content-Type', 'application/json');
		var query = metadata.getMetadata('Classes').queryForAll;
		console.log("query: "+query);
		//var query = 'select name from apexclass';
	    var data = SOQLServices.executeQuery(query, connection.getConnection(req, res));
	    //res.send(JSON.stringify(SOQLServices.records));
	    
	    res.send(JSON.stringify(data));
	    
	}else{
		console.log('token not found! redirecting to login page');
		res.send(JSON.stringify({"Response":"Need access token..."}));
		
	} 
	res.end();
});
//Classes end
app.listen(process.env.port || process.env.PORT || 8080);