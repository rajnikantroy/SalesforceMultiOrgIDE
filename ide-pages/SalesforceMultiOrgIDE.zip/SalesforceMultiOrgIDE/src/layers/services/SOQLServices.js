var sf = require('node-salesforce');
	
	function executeQuery(query, connection){
		console.log("inside executeQuery");
		if(query && connection){
			return getResult(query, connection);
		}
	}
	var count = 0;
	function getCount(query, connection){
		
		connection.query(query, function(err, result) {
			  if (err) { return err; }
			  console.log("fetched : " + result.records.length);
			  count = result.records.length;
			});
		return count;
	}
	var records = [];
	function getResult(query, connection){
		console.log("inside getResult");
		//var records = [];
		connection.query(query, function(err, result) {
			  if (err) { return err; }
			  console.log("total : " + result.totalSize);
			  //console.log("fetched : " + result.records.length);
			  console.log("inside getResult, result.totalSize: "+result.totalSize);
			  records = result.records;
			  return records;
			  /*for(var i=0; i<result.records.length; i++){
					//console.log(result.records[i].Name);
					records.push(result.records[i]);
			  }*/
			});
		return records;
	}	
module.exports.executeQuery = executeQuery;
module.exports.getCount = getCount;
//module.exports.records = records;