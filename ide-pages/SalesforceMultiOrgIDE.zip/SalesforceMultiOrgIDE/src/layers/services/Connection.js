var sf = require('node-salesforce');
var cookies = require('cookies')

var environments = [];
	
	function addEnvironment(environment){
		if(environment){
			environments.push(environment);
		}
	}
	 function getConnection(req, res){
		 //var cookie = res.cookies;
		 var latestEnvironment = environments.length;
		 if(latestEnvironment){
			 //cookie.set('access-token', environments[latestEnvironment-1].token, { signed: true });
			 return new sf.Connection({
			  	  instanceUrl : environments[latestEnvironment-1].url,
			  	  accessToken : environments[latestEnvironment-1].token
			  	})
		 }else{
			 return null;
		 }
	 }
	 
module.exports.addEnvironment = addEnvironment;
module.exports.getConnection = getConnection;